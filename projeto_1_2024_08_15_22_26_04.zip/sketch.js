function setup() {
  createCanvas(300, 300);
 background('whit');
}
  
function draw() {
  
 
  stroke('pink')
  fill('purple');
  
  //console.log(mouseIsPressed);
  
  if(mouseIsPressed) {
   rect(mouseX,mouseY,39,25);
  }
}
